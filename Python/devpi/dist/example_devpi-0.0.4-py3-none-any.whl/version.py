__version__ = "0.0.4"

def main():
    print(__version__)
    return __version__

if __name__ == '__main__':
    main()