.. _example_devpi_index:

Welcome to example_devpi's documentation!
===================================

:attention: This manual and the  following chapters, are not part of the
            devpi manual itself.


This document is part of the sample project used in the
`devpi user manual <http://doc.devpi.net/latest/userman/index.html>`_.

See :ref:`overview` chapter for details on this trivial project.

Contents:

.. toctree::
   :maxdepth: 2

   overview

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
